import java.awt.event.*;
import java.lang.Integer;

public class Controller implements ActionListener{
	private Model m;
	private View v;
	
	public Controller(){
	}
	
	public void actionPerformed(ActionEvent e){ 
		if (e.getSource().equals (v.resetButton))
		{
			m.set(0);
		} else if (e.getSource().equals(v.setButton)) {
			String valueString = v.valueField.getText();
			try {
				int value = Integer.parseInt(valueString);
				m.set(value);				
			} catch (Exception ex) { System.out.println("The text is not a valid integer");}
		}
	     
	}
	
	public void setModel(Model m){
		this.m = m;
	}
	
	public Model getModel(){
		return m;
	}
	
	public void setView(View v){
		this.v = v;
	}
	
	public View getView(){
		return v;
	}

}