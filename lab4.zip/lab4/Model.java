
public class Model extends java.util.Observable{
	
	private int counter;
	
	
	public Model(){
	}
	
	public void run(){
		while(true){
			try { Thread.sleep(1000); } catch (Exception e) {};
				counter++;
				setChanged();
				notifyObservers(counter);
		}
	}
	
	public void set(int b){
		counter = b;
		setChanged();
		notifyObservers(counter);
	}
	
	public int get(){
		return counter;
	}
	
}