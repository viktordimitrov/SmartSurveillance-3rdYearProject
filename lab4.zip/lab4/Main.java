
public class Main {
	public static void main(String[] args) {
		Model m1 = new Model();
		View v1 = new View();
		
		m1.addObserver(v1);
		
		Controller c1 = new Controller();
		c1.setModel(m1);
		c1.setView(v1);
		
		v1.addController(c1);
		m1.run();
	}
}