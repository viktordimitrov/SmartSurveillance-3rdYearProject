import javax.swing.*;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Container;
import java.lang.Integer;
import java.util.Observable;
import java.awt.event.ActionListener;

public class View implements java.util.Observer{
	public JButton resetButton, setButton;
	public JTextField counterField, valueField;
	
	public View(){

		JFrame frame = new JFrame("A Simple MVC");
		Container contentPane = frame.getContentPane();
		contentPane.setLayout( new BorderLayout());
		
		JPanel topPanel = new JPanel();
		JPanel bottomPanel = new JPanel();
		contentPane.add( "West", topPanel );
		contentPane.add ("East", bottomPanel);
				
		topPanel.add("West", new JLabel("Counter"));
		counterField = new JTextField(10);
		counterField.setEditable(false);
		topPanel.add("East",counterField);
		
		bottomPanel.setLayout(new BorderLayout());
		valueField = new JTextField( 10);
		counterField.setEditable(true);
		bottomPanel.add("North",valueField);
		JPanel buttonPanel = new JPanel();
		bottomPanel.add("South",buttonPanel);
		buttonPanel.setLayout(new FlowLayout());
		resetButton = new JButton ("RESET");
		buttonPanel.add(resetButton);
		//resetButton.addActionListener(c);
		buttonPanel.add(resetButton);
		setButton = new JButton ("SET");
		buttonPanel.add(setButton);
		//setButton.addActionListener(c);
		buttonPanel.add(setButton);

		frame.setSize(350,100);
		frame.setLocation(100,100);
		frame.setVisible(true);
	}
	
	public void update(Observable obs, Object obj){
		counterField.setText("" + ((Integer)obj).intValue());
	}
	
	public void addController(ActionListener c){
		resetButton.addActionListener(c);
		setButton.addActionListener(c);
	}
	
	public void setValue(int v){
		counterField.setText("" + v);
	}
}